package net.dries007.tapemouse;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Text;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;

public class ClientEventHandler {
   private static final Map<String, KeyBinding> KEYBIND_ARRAY = (Map)ObfuscationReflectionHelper.getPrivateValue(KeyBinding.class, (Object)null, "field_74516_a");
   private final Minecraft mc = Minecraft.func_71410_x();
   private int delay;
   private KeyBinding keyBinding;
   private int i;

   public ClientEventHandler() {
      MinecraftForge.EVENT_BUS.register(this);
      if (KEYBIND_ARRAY == null) {
         RuntimeException e = new NullPointerException("KEYBIND_ARRAY was null.");
         TapeMouse.LOGGER.fatal("Something has gone wrong fetching the keybinding list. I guess we die now.", e);
         throw e;
      }
   }

   @SubscribeEvent
   public void textRenderEvent(Text event) {
      if (this.keyBinding != null) {
         if (!(this.mc.field_71462_r instanceof GuiMainMenu) && !(this.mc.field_71462_r instanceof GuiChat)) {
            event.getLeft().add("TapeMouse active: " + this.keyBinding.getDisplayName() + " (" + this.keyBinding.func_151464_g().replaceFirst("^key\\.", "") + ')');
            event.getLeft().add("Delay: " + this.i + " / " + this.delay);
         } else {
            event.getLeft().add("TapeMouse paused. If you want to AFK, use ALT+TAB.");
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void tickEvent(ClientTickEvent event) {
      if (event.phase == Phase.START) {
         if (!(this.mc.field_71462_r instanceof GuiMainMenu) && !(this.mc.field_71462_r instanceof GuiChat)) {
            if (this.keyBinding != null) {
               if (this.i++ >= this.delay) {
                  this.i = 0;
                  if (this.delay == 0) {
                     KeyBinding.func_74510_a(this.keyBinding.func_151463_i(), true);
                  }

                  KeyBinding.func_74507_a(this.keyBinding.func_151463_i());
               }
            }
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void chatEvent(ClientChatEvent event) {
      if (event.getMessage().startsWith("/tapemouse")) {
         event.setCanceled(true);
         String[] args = event.getOriginalMessage().split("\\s");
         GuiNewChat gui = this.mc.field_71456_v.func_146158_b();
         gui.func_146239_a(event.getOriginalMessage());

         try {
            this.handleCommand(gui, args);
         } catch (Exception var5) {
            gui.func_146227_a((new TextComponentString("An error occurred trying to run the tapemouse command:")).func_150255_a((new Style()).func_150238_a(TextFormatting.RED)));
            gui.func_146227_a((new TextComponentString(var5.toString())).func_150255_a((new Style()).func_150238_a(TextFormatting.RED)));
            TapeMouse.LOGGER.error("An error occurred trying to run the tapemouse command:", var5);
         }

      }
   }

   private void handleCommand(GuiNewChat gui, String[] args) throws Exception {
      switch(args.length) {
      case 2:
         if (args[1].equalsIgnoreCase("off")) {
            this.keyBinding = null;
            return;
         }

         if (args[1].equalsIgnoreCase("list")) {
            List<String> keys = (List)KEYBIND_ARRAY.keySet().stream().map((k) -> {
               return k.replaceFirst("^key\\.", "");
            }).sorted().collect(Collectors.toList());
            gui.func_146227_a(new TextComponentString(String.join(", ", keys)));
         } else {
            gui.func_146227_a((new TextComponentString("Missing delay parameter.")).func_150255_a((new Style()).func_150238_a(TextFormatting.RED)));
         }
         break;
      case 3:
         KeyBinding keyBinding = (KeyBinding)KEYBIND_ARRAY.get("key." + args[1]);
         if (keyBinding == null) {
            keyBinding = (KeyBinding)KEYBIND_ARRAY.get(args[1]);
         }

         if (keyBinding == null) {
            gui.func_146227_a((new TextComponentString(args[1] + " is not a valid keybinding.")).func_150255_a((new Style()).func_150238_a(TextFormatting.RED)));
            return;
         }

         int delay;
         try {
            delay = Integer.parseInt(args[2]);
            if (delay < 0) {
               throw new Exception("bad user");
            }
         } catch (Exception var6) {
            gui.func_146227_a((new TextComponentString(args[1] + " is not a positive number or 0.")).func_150255_a((new Style()).func_150238_a(TextFormatting.RED)));
            return;
         }

         this.delay = delay;
         this.i = 0;
         this.keyBinding = keyBinding;
         break;
      default:
         gui.func_146227_a((new TextComponentString("TapeMouse help: ")).func_150255_a((new Style()).func_150238_a(TextFormatting.AQUA)));
         gui.func_146227_a(new TextComponentString("Run '/tapemouse list' to get a list of keybindings."));
         gui.func_146227_a(new TextComponentString("Run '/tapemouse off' to stop TapeMouse."));
         gui.func_146227_a(new TextComponentString("Run '/tapemouse <binding> <delay>' to start TapeMouse."));
         gui.func_146227_a(new TextComponentString("  delay is the number of ticks between every keypress. Set to 0 to hold down the key."));
         return;
      }

   }
}
