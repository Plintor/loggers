package com.wao.silent.ui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class draw {
   // $FF: synthetic field
   private static final int[] lIIlIll;
   // $FF: synthetic field
   public static int drowFps;
   // $FF: synthetic field
   private static final String[] lIIlIIl;

   private static void llIlIll() {
      lIIlIIl = new String[lIIlIll[5]];
      lIIlIIl[lIIlIll[1]] = llIlIII("w1b/thupQAA=", "fuIOr");
      lIIlIIl[lIIlIll[0]] = llIlIlI("6Frdo/ZjBjs=", "zsWxh");
      lIIlIIl[lIIlIll[3]] = llIlIlI("zkgntlY0FqUyhpZNZpmypA==", "CcnrM");
      lIIlIIl[lIIlIll[4]] = llIlIII("E76ij+tIyS1Ri05Nzq5mdQ==", "XOOAs");
   }

   @SubscribeEvent
   public void onUpdate(RenderGameOverlayEvent llllIIllIllllIl) {
      switch(null.$SwitchMap$net$minecraftforge$client$event$RenderGameOverlayEvent$ElementType[llllIIllIllllIl.getType().ordinal()]) {
      case 1:
         if (llIlllI(drowFps, lIIlIll[0])) {
            Minecraft.func_71410_x().field_71466_p.func_238421_b_(llllIIllIllllIl.getMatrixStack(), String.valueOf((new StringBuilder()).append(lIIlIIl[lIIlIll[1]]).append(Minecraft.func_71410_x().field_71426_K).append(lIIlIIl[lIIlIll[0]])), 10.0F, 10.0F, lIIlIll[2]);
            "".length();
            Minecraft.func_71410_x().field_71466_p.func_238421_b_(llllIIllIllllIl.getMatrixStack(), lIIlIIl[lIIlIll[3]], 10.0F, 23.0F, lIIlIll[2]);
            "".length();
            "".length();
            if ((69 + 39 - 70 + 145 ^ 16 + 77 - -8 + 78) < 0) {
               return;
            }
         } else {
            Minecraft.func_71410_x().field_71466_p.func_238421_b_(llllIIllIllllIl.getMatrixStack(), lIIlIIl[lIIlIll[4]], 10.0F, 10.0F, lIIlIll[2]);
            "".length();
            "".length();
            if ("   ".length() <= 0) {
               return;
            }
         }
      default:
      }
   }

   private static String llIlIII(String llllIIllIllIlII, String llllIIllIllIIll) {
      try {
         double llllIIllIllIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllIIllIllIIll.getBytes(StandardCharsets.UTF_8)), lIIlIll[6]), "DES");
         Cipher llllIIllIllIllI = Cipher.getInstance("DES");
         llllIIllIllIllI.init(lIIlIll[3], llllIIllIllIIII);
         return new String(llllIIllIllIllI.doFinal(Base64.getDecoder().decode(llllIIllIllIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   private static boolean llIlllI(int var0, int var1) {
      return var0 == var1;
   }

   private static String llIlIlI(String llllIIllIlIIlIl, String llllIIllIlIIlII) {
      try {
         SecretKeySpec llllIIllIlIlIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllIIllIlIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
         String llllIIllIlIIIlI = Cipher.getInstance("Blowfish");
         llllIIllIlIIIlI.init(lIIlIll[3], llllIIllIlIlIlI);
         return new String(llllIIllIlIIIlI.doFinal(Base64.getDecoder().decode(llllIIllIlIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   private static void llIllIl() {
      lIIlIll = new int[7];
      lIIlIll[0] = " ".length();
      lIIlIll[1] = (157 + 183 - 268 + 115 ^ 63 + 13 - -38 + 76) & (13 + 31 - -18 + 117 ^ 99 + 27 - 79 + 135 ^ -" ".length());
      lIIlIll[2] = -" ".length();
      lIIlIll[3] = "  ".length();
      lIIlIll[4] = "   ".length();
      lIIlIll[5] = 29 ^ 71 ^ 43 ^ 117;
      lIIlIll[6] = 0 + 2 - -112 + 17 ^ 104 + 37 - 6 + 4;
   }

   static {
      llIllIl();
      llIlIll();
      drowFps = lIIlIll[0];
   }
}
