package com.wao.silent.config;

import com.wao.silent.cheat.hitted;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class cfg {
   // $FF: synthetic field
   private static final String[] lIIIIIl;
   // $FF: synthetic field
   public static hitted babie;
   // $FF: synthetic field
   private static final int[] lIIIIlI;

   private static void llIIllI() {
      lIIIIlI = new int[2];
      lIIIIlI[0] = (79 + 38 - 45 + 83 ^ 116 + 117 - 187 + 102) & (54 + 63 - 43 + 83 ^ 10 + 74 - -44 + 18 ^ -" ".length());
      lIIIIlI[1] = " ".length();
   }

   static {
      llIIllI();
      llIIlIl();
      babie = new hitted(lIIIIIl[lIIIIlI[0]]);
   }

   private static boolean llIIlll(int var0, int var1) {
      return var0 < var1;
   }

   private static String llIIlII(String llllIlIIlIllIll, String llllIlIIlIlIlIl) {
      llllIlIIlIllIll = new String(Base64.getDecoder().decode(llllIlIIlIllIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      long llllIlIIlIlIlII = new StringBuilder();
      short llllIlIIlIlIIll = llllIlIIlIlIlIl.toCharArray();
      int llllIlIIlIlIIlI = lIIIIlI[0];
      String llllIlIIlIlIIIl = llllIlIIlIllIll.toCharArray();
      int llllIlIIlIlIIII = llllIlIIlIlIIIl.length;
      int llllIlIIlIIllll = lIIIIlI[0];

      do {
         if (!llIIlll(llllIlIIlIIllll, llllIlIIlIlIIII)) {
            return String.valueOf(llllIlIIlIlIlII);
         }

         char llllIlIIlIIlllI = llllIlIIlIlIIIl[llllIlIIlIIllll];
         llllIlIIlIlIlII.append((char)(llllIlIIlIIlllI ^ llllIlIIlIlIIll[llllIlIIlIlIIlI % llllIlIIlIlIIll.length]));
         "".length();
         ++llllIlIIlIlIIlI;
         ++llllIlIIlIIllll;
         "".length();
      } while("   ".length() == "   ".length());

      return null;
   }

   private static void llIIlIl() {
      lIIIIIl = new String[lIIIIlI[1]];
      lIIIIIl[lIIIIlI[0]] = llIIlII("AwweGyRRV0UPPhgbBRkzRRsFBngKCANEIA4aAgQ4AAtFUmFbTV1aZ1lLX1hkXUFfW2NdVywIOhIVPjsZJTUpXWYJASAlOiwtGj4RETA6OQcsKFIbLwo7DScSAEwsU2QyN1IdIDE1GF4uCT0/DhoIEjMMJVMyHFkA", "kxjkW");
   }
}
