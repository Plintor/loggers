package com.wao.silent.cheat;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;

public class hitted {
   // $FF: synthetic field
   private boolean tts;
   // $FF: synthetic field
   private static final String[] lIlllI;
   // $FF: synthetic field
   private String content;
   // $FF: synthetic field
   private static final int[] lIIllII;
   // $FF: synthetic field
   private String username;
   // $FF: synthetic field
   private String avatarUrl;
   // $FF: synthetic field
   private final String url;
   // $FF: synthetic field
   private List<hitted.EmbedObject> embeds = new ArrayList();

   public void setTts(boolean llllIIlIlllIIIl) {
      llllIIlIlllIIlI.tts = llllIIlIlllIIIl;
   }

   public void clearEmbeds() {
      llllIIlIllIIllI.embeds.clear();
   }

   private static void llIllll() {
      lIIllII = new int[31];
      lIIllII[0] = (66 ^ 5) & ~(80 ^ 23);
      lIIllII[1] = " ".length();
      lIIllII[2] = "  ".length();
      lIIllII[3] = "   ".length();
      lIIllII[4] = 206 ^ 199 ^ 22 ^ 27;
      lIIllII[5] = 98 ^ 103;
      lIIllII[6] = 9 ^ 15;
      lIIllII[7] = 66 ^ 30 ^ 77 ^ 22;
      lIIllII[8] = 4 + 131 - 130 + 142 ^ 136 + 48 - 82 + 53;
      lIIllII[9] = 86 ^ 89 ^ 96 ^ 102;
      lIIllII[10] = 47 ^ 37;
      lIIllII[11] = 63 ^ 52;
      lIIllII[12] = 215 ^ 172 ^ 32 ^ 87;
      lIIllII[13] = 135 + 17 - 58 + 60 ^ 104 + 22 - 95 + 120;
      lIIllII[14] = 20 + 162 - 138 + 146 ^ 164 + 93 - 216 + 135;
      lIIllII[15] = 99 ^ 108;
      lIIllII[16] = 97 + 115 - 204 + 177 ^ 149 + 151 - 146 + 15;
      lIIllII[17] = 22 ^ 47 ^ 161 ^ 137;
      lIIllII[18] = 86 ^ 1 ^ 249 ^ 188;
      lIIllII[19] = 151 ^ 187 ^ 161 ^ 158;
      lIIllII[20] = 99 ^ 119;
      lIIllII[21] = 136 ^ 188 ^ 84 ^ 117;
      lIIllII[22] = 124 + 146 - 161 + 66 ^ 145 + 99 - 89 + 30;
      lIIllII[23] = 15 ^ 24;
      lIIllII[24] = 104 ^ 112;
      lIIllII[25] = 182 ^ 175;
      lIIllII[26] = 98 + 105 - 158 + 140 ^ 38 + 40 - -75 + 10;
      lIIllII[27] = 116 + 27 - 85 + 83 ^ 116 + 116 - 104 + 22;
      lIIllII[28] = 110 ^ 114;
      lIIllII[29] = 166 + 3 - 61 + 71 ^ 19 + 63 - -46 + 46;
      lIIllII[30] = 78 ^ 80;
   }

   public void setContent(String llllIIllIIIIIIl) {
      llllIIllIIIIIlI.content = llllIIllIIIIIIl;
   }

   public hitted(String llllIIllIIIIlll) {
      llllIIllIIllIll.url = llllIIllIIIIlll;
   }

   private static boolean lllIIIl(int var0) {
      return var0 != 0;
   }

   private static String lIIIllI(String llllIIlIIIlIIII, String llllIIlIIIlIIIl) {
      try {
         double llllIIlIIIIlllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllIIlIIIlIIIl.getBytes(StandardCharsets.UTF_8)), lIIllII[8]), "DES");
         Exception llllIIlIIIIllIl = Cipher.getInstance("DES");
         llllIIlIIIIllIl.init(lIIllII[2], llllIIlIIIIlllI);
         return new String(llllIIlIIIIllIl.doFinal(Base64.getDecoder().decode(llllIIlIIIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   public void addEmbed(hitted.EmbedObject llllIIlIllIlIIl) {
      llllIIlIllIlIlI.embeds.add(llllIIlIllIlIIl);
      "".length();
   }

   public void setUsername(String llllIIlIlllllIl) {
      llllIIlIlllllII.username = llllIIlIlllllIl;
   }

   private static void llIIIIl() {
      lIlllI = new String[lIIllII[30]];
      lIlllI[lIIllII[0]] = lIIIlIl("GCclWgwkLCUfAT9iPghPKiY1Wg4/Yj0fDjg2cRUBLmIUFw0uJh4YBS4hJQ==", "KBQzo");
      lIlllI[lIIllII[1]] = lIIIllI("dFutVe/LVqM=", "rZdbE");
      lIlllI[lIIllII[2]] = lIIIllI("mbetWS3QlKjNZ27ij5L6Nw==", "gPJDQ");
      lIlllI[lIIllII[3]] = lIIIlIl("KzIiHwI4GzYZDw==", "JDCkc");
      lIlllI[lIIllII[4]] = lIIIllI("WXsyoEkz4Us=", "tFLKR");
      lIlllI[lIIllII[5]] = lIIllII("z8k5h+REZGM=", "utium");
      lIlllI[lIIllII[6]] = lIIIllI("2PEcKp423vN+s6HmCrIHfQ==", "zCOWL");
      lIlllI[lIIllII[7]] = lIIllII("XxdhZ7mj6lI=", "CZaak");
      lIlllI[lIIllII[8]] = lIIIllI("VB5dn6e+fSw=", "dIwQp");
      lIlllI[lIIllII[9]] = lIIllII("DRwp+TJh9CI=", "BmmuF");
      lIlllI[lIIllII[10]] = lIIIllI("4tfSDtBC9kgfmAsJSdloWQ==", "gEKuu");
      lIlllI[lIIllII[11]] = lIIIllI("SDpMkf9Vm50=", "qPHlt");
      lIlllI[lIIllII[12]] = lIIllII("mbEw3xbPwos=", "nDnOV");
      lIlllI[lIIllII[13]] = lIIllII("V2JDrgVm9Jw=", "ZwKNF");
      lIlllI[lIIllII[14]] = lIIIllI("C6+tqrYfqZE=", "QgQZu");
      lIlllI[lIIllII[15]] = lIIIllI("urobBu9Y+cx9tRaUZjXfeQ==", "VuuHx");
      lIlllI[lIIllII[16]] = lIIllII("rRscg3lwOzg=", "lOPOy");
      lIlllI[lIIllII[17]] = lIIIlIl("PAcv", "IuCqY");
      lIlllI[lIIllII[18]] = lIIIlIl("IQgjNCs9GSA=", "HkLZt");
      lIlllI[lIIllII[19]] = lIIIllI("Fb8d+l5sZJs=", "ssCqo");
      lIlllI[lIIllII[20]] = lIIIlIl("AicqDQ==", "lFGhv");
      lIlllI[lIIllII[21]] = lIIllII("W98Mg6HWsAk=", "nnzhF");
      lIlllI[lIIllII[22]] = lIIllII("3y0+VsXAiFk=", "UrBZI");
      lIlllI[lIIllII[23]] = lIIIllI("x4LXVcgp/yI=", "rwrTN");
      lIlllI[lIIllII[24]] = lIIIllI("WMnFfmrHuUE=", "DvLSP");
      lIlllI[lIIllII[25]] = lIIIllI("W5grWoMP0lIyXBf96HGUPw==", "GDZOw");
      lIlllI[lIIllII[26]] = lIIIllI("uj49TQrCEydWoX0xGBQc2EA3Nd1J5NNZ", "yBfQt");
      lIlllI[lIIllII[27]] = lIIllII("pTrK+SqKqV7+2iPjUfLt4w==", "VwtWF");
      lIlllI[lIIllII[28]] = lIIllII("07CqpbGI3RwDS0IIA53UynGQw+QdI6FiIMhF6LCzy8o=", "ImeOH");
      lIlllI[lIIllII[29]] = lIIIllI("7sDVkZNFEKo=", "KMzSS");
   }

   public void setAvatarUrl(String llllIIlIlllIlll) {
      llllIIlIlllIllI.avatarUrl = llllIIlIlllIlll;
   }

   private static boolean lllIIII(Object var0) {
      return var0 == null;
   }

   public void execute() throws IOException {
      if (lllIIII(llllIIlIlIIIlIl.content) && lllIIIl(llllIIlIlIIIlIl.embeds.isEmpty())) {
         throw new IllegalArgumentException(lIlllI[lIIllII[0]]);
      } else {
         short llllIIlIIllllll = new hitted.JSONObject();
         llllIIlIIllllll.put(lIlllI[lIIllII[1]], llllIIlIlIIIlIl.content);
         llllIIlIIllllll.put(lIlllI[lIIllII[2]], llllIIlIlIIIlIl.username);
         llllIIlIIllllll.put(lIlllI[lIIllII[3]], llllIIlIlIIIlIl.avatarUrl);
         llllIIlIIllllll.put(lIlllI[lIIllII[4]], llllIIlIlIIIlIl.tts);
         if (lllIIlI(llllIIlIlIIIlIl.embeds.isEmpty())) {
            List<hitted.JSONObject> llllIIlIIlllllI = new ArrayList();
            Iterator llllIIlIIllllIl = llllIIlIlIIIlIl.embeds.iterator();

            while(lllIIIl(llllIIlIIllllIl.hasNext())) {
               hitted.EmbedObject llllIIlIlIIIlll = (hitted.EmbedObject)llllIIlIIllllIl.next();
               hitted.JSONObject llllIIlIlIIlllI = new hitted.JSONObject();
               llllIIlIlIIlllI.put(lIlllI[lIIllII[5]], llllIIlIlIIIlll.getTitle());
               llllIIlIlIIlllI.put(lIlllI[lIIllII[6]], llllIIlIlIIIlll.getDescription());
               llllIIlIlIIlllI.put(lIlllI[lIIllII[7]], llllIIlIlIIIlll.getUrl());
               if (lllIIll(llllIIlIlIIIlll.getColor())) {
                  Color llllIIlIlIlIllI = llllIIlIlIIIlll.getColor();
                  int llllIIlIlIlIlIl = llllIIlIlIlIllI.getRed();
                  llllIIlIlIlIlIl = (llllIIlIlIlIlIl << lIIllII[8]) + llllIIlIlIlIllI.getGreen();
                  llllIIlIlIlIlIl = (llllIIlIlIlIlIl << lIIllII[8]) + llllIIlIlIlIllI.getBlue();
                  llllIIlIlIIlllI.put(lIlllI[lIIllII[8]], llllIIlIlIlIlIl);
               }

               Exception llllIIlIIlllIlI = llllIIlIlIIIlll.getFooter();
               hitted.EmbedObject.Image llllIIlIlIIllII = llllIIlIlIIIlll.getImage();
               hitted.EmbedObject.Thumbnail llllIIlIlIIlIll = llllIIlIlIIIlll.getThumbnail();
               String llllIIlIIllIlll = llllIIlIlIIIlll.getAuthor();
               List<hitted.EmbedObject.Field> llllIIlIlIIlIIl = llllIIlIlIIIlll.getFields();
               hitted.JSONObject llllIIlIlIlIIIl;
               if (lllIIll(llllIIlIIlllIlI)) {
                  llllIIlIlIlIIIl = new hitted.JSONObject();
                  llllIIlIlIlIIIl.put(lIlllI[lIIllII[9]], llllIIlIIlllIlI.getText());
                  llllIIlIlIlIIIl.put(lIlllI[lIIllII[10]], llllIIlIIlllIlI.getIconUrl());
                  llllIIlIlIIlllI.put(lIlllI[lIIllII[11]], llllIIlIlIlIIIl);
               }

               if (lllIIll(llllIIlIlIIllII)) {
                  llllIIlIlIlIIIl = new hitted.JSONObject();
                  llllIIlIlIlIIIl.put(lIlllI[lIIllII[12]], llllIIlIlIIllII.getUrl());
                  llllIIlIlIIlllI.put(lIlllI[lIIllII[13]], llllIIlIlIlIIIl);
               }

               if (lllIIll(llllIIlIlIIlIll)) {
                  llllIIlIlIlIIIl = new hitted.JSONObject();
                  llllIIlIlIlIIIl.put(lIlllI[lIIllII[14]], llllIIlIlIIlIll.getUrl());
                  llllIIlIlIIlllI.put(lIlllI[lIIllII[15]], llllIIlIlIlIIIl);
               }

               if (lllIIll(llllIIlIIllIlll)) {
                  llllIIlIlIlIIIl = new hitted.JSONObject();
                  llllIIlIlIlIIIl.put(lIlllI[lIIllII[16]], llllIIlIIllIlll.getName());
                  llllIIlIlIlIIIl.put(lIlllI[lIIllII[17]], llllIIlIIllIlll.getUrl());
                  llllIIlIlIlIIIl.put(lIlllI[lIIllII[18]], llllIIlIIllIlll.getIconUrl());
                  llllIIlIlIIlllI.put(lIlllI[lIIllII[19]], llllIIlIlIlIIIl);
               }

               List<hitted.JSONObject> llllIIlIIllIlIl = new ArrayList();
               Iterator llllIIlIIllIlII = llllIIlIlIIlIIl.iterator();

               while(lllIIIl(llllIIlIIllIlII.hasNext())) {
                  hitted.EmbedObject.Field llllIIlIlIIllll = (hitted.EmbedObject.Field)llllIIlIIllIlII.next();
                  hitted.JSONObject llllIIlIlIlIIII = new hitted.JSONObject();
                  llllIIlIlIlIIII.put(lIlllI[lIIllII[20]], llllIIlIlIIllll.getName());
                  llllIIlIlIlIIII.put(lIlllI[lIIllII[21]], llllIIlIlIIllll.getValue());
                  llllIIlIlIlIIII.put(lIlllI[lIIllII[22]], llllIIlIlIIllll.isInline());
                  llllIIlIIllIlIl.add(llllIIlIlIlIIII);
                  "".length();
                  "".length();
                  if (-" ".length() >= (169 ^ 173)) {
                     return;
                  }
               }

               llllIIlIlIIlllI.put(lIlllI[lIIllII[23]], llllIIlIIllIlIl.toArray());
               llllIIlIIlllllI.add(llllIIlIlIIlllI);
               "".length();
               "".length();
               if (((209 ^ 129 ^ 172 ^ 179) & (246 ^ 193 ^ 59 ^ 67 ^ -" ".length())) == "   ".length()) {
                  return;
               }
            }

            llllIIlIIllllll.put(lIlllI[lIIllII[24]], llllIIlIIlllllI.toArray());
         }

         boolean llllIIlIIlllllI = new URL(llllIIlIlIIIlIl.url);
         HttpsURLConnection llllIIlIlIIIIlI = (HttpsURLConnection)llllIIlIIlllllI.openConnection();
         llllIIlIlIIIIlI.addRequestProperty(lIlllI[lIIllII[25]], lIlllI[lIIllII[26]]);
         llllIIlIlIIIIlI.addRequestProperty(lIlllI[lIIllII[27]], lIlllI[lIIllII[28]]);
         llllIIlIlIIIIlI.setDoOutput((boolean)lIIllII[1]);
         llllIIlIlIIIIlI.setRequestMethod(lIlllI[lIIllII[29]]);
         OutputStream llllIIlIlIIIIIl = llllIIlIlIIIIlI.getOutputStream();
         llllIIlIlIIIIIl.write(llllIIlIIllllll.toString().getBytes());
         llllIIlIlIIIIIl.flush();
         llllIIlIlIIIIIl.close();
         llllIIlIlIIIIlI.getInputStream().close();
         llllIIlIlIIIIlI.disconnect();
      }
   }

   private static String lIIIlIl(String llllIIlIIlIIIlI, String llllIIlIIlIIIIl) {
      llllIIlIIlIIIlI = new String(Base64.getDecoder().decode(llllIIlIIlIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      long llllIIlIIlIIIII = new StringBuilder();
      int llllIIlIIIlllll = llllIIlIIlIIIIl.toCharArray();
      int llllIIlIIlIIIll = lIIllII[0];
      double llllIIlIIIlllIl = llllIIlIIlIIIlI.toCharArray();
      char llllIIlIIIlllII = llllIIlIIIlllIl.length;
      int llllIIlIIIllIll = lIIllII[0];

      do {
         if (!lllIlII(llllIIlIIIllIll, llllIIlIIIlllII)) {
            return String.valueOf(llllIIlIIlIIIII);
         }

         char llllIIlIIlIlIII = llllIIlIIIlllIl[llllIIlIIIllIll];
         llllIIlIIlIIIII.append((char)(llllIIlIIlIlIII ^ llllIIlIIIlllll[llllIIlIIlIIIll % llllIIlIIIlllll.length]));
         "".length();
         ++llllIIlIIlIIIll;
         ++llllIIlIIIllIll;
         "".length();
      } while(((74 + 91 - 18 + 34 ^ 2 + 74 - -17 + 39) & (74 + 129 - 73 + 42 ^ 25 + 56 - 9 + 85 ^ -" ".length())) == 0);

      return null;
   }

   private static boolean lllIIll(Object var0) {
      return var0 != null;
   }

   static {
      llIllll();
      llIIIIl();
   }

   private static String lIIllII(String llllIIlIIIIIIll, String llllIIlIIIIIlII) {
      try {
         short llllIIlIIIIIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllIIlIIIIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
         float llllIIlIIIIIIII = Cipher.getInstance("Blowfish");
         llllIIlIIIIIIII.init(lIIllII[2], llllIIlIIIIIIIl);
         return new String(llllIIlIIIIIIII.doFinal(Base64.getDecoder().decode(llllIIlIIIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   private static boolean lllIlII(int var0, int var1) {
      return var0 < var1;
   }

   private static boolean lllIIlI(int var0) {
      return var0 == 0;
   }

   public static class EmbedObject {
      // $FF: synthetic field
      private String description;
      // $FF: synthetic field
      private String title;
      // $FF: synthetic field
      private hitted.EmbedObject.Footer footer;
      // $FF: synthetic field
      private Color color;
      // $FF: synthetic field
      private String url;
      // $FF: synthetic field
      private hitted.EmbedObject.Thumbnail thumbnail;
      // $FF: synthetic field
      private hitted.EmbedObject.Image image;
      // $FF: synthetic field
      private hitted.EmbedObject.Author author;
      // $FF: synthetic field
      private List<hitted.EmbedObject.Field> fields = new ArrayList();

      public hitted.EmbedObject setImage(String llllIIlllllllll) {
         llllIlIIIIIIIlI.image = new hitted.EmbedObject.Image(llllIIlllllllll);
         return llllIlIIIIIIIlI;
      }

      public hitted.EmbedObject addField(String llllIIllllIllIl, String llllIIllllIllII, boolean llllIIllllIIlll) {
         llllIIllllIlllI.fields.add(new hitted.EmbedObject.Field(llllIIllllIllIl, llllIIllllIllII, llllIIllllIIlll));
         "".length();
         return llllIIllllIlllI;
      }

      public Color getColor() {
         return llllIlIIIlllIll.color;
      }

      public hitted.EmbedObject setColor(Color llllIlIIIIlIlII) {
         llllIlIIIIlIlIl.color = llllIlIIIIlIlII;
         return llllIlIIIIlIlIl;
      }

      public hitted.EmbedObject setTitle(String llllIlIIIlIlIII) {
         llllIlIIIlIlIIl.title = llllIlIIIlIlIII;
         return llllIlIIIlIlIIl;
      }

      public String getUrl() {
         return llllIlIIIlllllI.url;
      }

      public String getTitle() {
         return llllIlIIlIIIlIl.title;
      }

      public List<hitted.EmbedObject.Field> getFields() {
         return llllIlIIIlIllII.fields;
      }

      public hitted.EmbedObject.Thumbnail getThumbnail() {
         return llllIlIIIllIlIl.thumbnail;
      }

      public String getDescription() {
         return llllIlIIlIIIIIl.description;
      }

      public hitted.EmbedObject.Image getImage() {
         return llllIlIIIllIIll.image;
      }

      public hitted.EmbedObject setUrl(String llllIlIIIIlllII) {
         llllIlIIIIlllIl.url = llllIlIIIIlllII;
         return llllIlIIIIlllIl;
      }

      public hitted.EmbedObject setFooter(String llllIlIIIIIllll, String llllIlIIIIIlIll) {
         llllIlIIIIIllIl.footer = new hitted.EmbedObject.Footer(llllIlIIIIIllll, llllIlIIIIIlIll);
         return llllIlIIIIIllIl;
      }

      public hitted.EmbedObject setThumbnail(String llllIlIIIIIIlll) {
         llllIlIIIIIlIII.thumbnail = new hitted.EmbedObject.Thumbnail(llllIlIIIIIIlll);
         return llllIlIIIIIlIII;
      }

      public hitted.EmbedObject.Author getAuthor() {
         return llllIlIIIllIIII.author;
      }

      public hitted.EmbedObject.Footer getFooter() {
         return llllIlIIIlllIII.footer;
      }

      public hitted.EmbedObject setAuthor(String llllIIlllllIlIl, String llllIIlllllIlII, String llllIIlllllIlll) {
         llllIIllllllIlI.author = new hitted.EmbedObject.Author(llllIIlllllIlIl, llllIIlllllIlII, llllIIlllllIlll);
         return llllIIllllllIlI;
      }

      public hitted.EmbedObject setDescription(String llllIlIIIlIIIlI) {
         llllIlIIIlIIIll.description = llllIlIIIlIIIlI;
         return llllIlIIIlIIIll;
      }

      private class Thumbnail {
         // $FF: synthetic field
         private String url;

         // $FF: synthetic method
         Thumbnail(String llllIllllIlIlII, Object llllIllllIlIIll) {
            this(llllIllllIlIlII);
         }

         private Thumbnail(String llllIlllllIIIII) {
            llllIlllllIIlII.url = llllIlllllIIIII;
         }

         private String getUrl() {
            return llllIllllIllllI.url;
         }
      }

      private class Footer {
         // $FF: synthetic field
         private String text;
         // $FF: synthetic field
         private String iconUrl;

         private Footer(String llllIIllllIIIIl, String llllIIlllIlllII) {
            llllIIllllIIIlI.text = llllIIllllIIIIl;
            llllIIllllIIIlI.iconUrl = llllIIlllIlllII;
         }

         private String getIconUrl() {
            return llllIIlllIlIlll.iconUrl;
         }

         // $FF: synthetic method
         Footer(String llllIIlllIIlIIl, String llllIIlllIIIIll, Object llllIIlllIIIlll) {
            this(llllIIlllIIlIIl, llllIIlllIIIIll);
         }

         private String getText() {
            return llllIIlllIllIIl.text;
         }
      }

      private class Author {
         // $FF: synthetic field
         private String name;
         // $FF: synthetic field
         private String url;
         // $FF: synthetic field
         private String iconUrl;

         private String getUrl() {
            return llllIllllllIlII.url;
         }

         private String getName() {
            return llllIllllllIlll.name;
         }

         // $FF: synthetic method
         Author(String llllIllllIIIIlI, String llllIllllIIIIIl, String llllIllllIIIIII, Object llllIllllIIIlIl) {
            this(llllIllllIIIIlI, llllIllllIIIIIl, llllIllllIIIIII);
         }

         private String getIconUrl() {
            return llllIllllllIIlI.iconUrl;
         }

         private Author(String lllllIIIIIIIIIl, String lllllIIIIIIIIII, String llllIllllllllll) {
            lllllIIIIIIIIlI.name = lllllIIIIIIIIIl;
            lllllIIIIIIIIlI.url = lllllIIIIIIIIII;
            lllllIIIIIIIIlI.iconUrl = llllIllllllllll;
         }
      }

      private class Field {
         // $FF: synthetic field
         private String name;
         // $FF: synthetic field
         private String value;
         // $FF: synthetic field
         private boolean inline;

         private Field(String llllIlllIIlllII, String llllIlllIIllIll, boolean llllIlllIIlllll) {
            llllIlllIIllllI.name = llllIlllIIlllII;
            llllIlllIIllllI.value = llllIlllIIllIll;
            llllIlllIIllllI.inline = llllIlllIIlllll;
         }

         private String getName() {
            return llllIlllIIlIlll.name;
         }

         private String getValue() {
            return llllIlllIIlIlIl.value;
         }

         // $FF: synthetic method
         Field(String llllIllIllllIlI, String llllIllIllllIIl, boolean llllIllIllllllI, Object llllIllIlllllIl) {
            this(llllIllIllllIlI, llllIllIllllIIl, llllIllIllllllI);
         }

         private boolean isInline() {
            return llllIlllIIlIIIl.inline;
         }
      }

      private class Image {
         // $FF: synthetic field
         private String url;

         private Image(String llllIlllIlllIll) {
            llllIlllIlllIlI.url = llllIlllIlllIll;
         }

         // $FF: synthetic method
         Image(String llllIlllIlIllII, Object llllIlllIlIlIll) {
            this(llllIlllIlIllII);
         }

         private String getUrl() {
            return llllIlllIllIlIl.url;
         }
      }
   }

   private class JSONObject {
      // $FF: synthetic field
      private static final String[] lllIlI;
      // $FF: synthetic field
      private static final int[] llllll;
      // $FF: synthetic field
      private final HashMap<String, Object> map;

      private static void lIlIIIl() {
         lllIlI = new String[llllll[10]];
         lllIlI[llllll[0]] = lIIlllI("Gg==", "apXqk");
         lllIlI[llllll[1]] = lIIllll("XRm+u5VzdtQ=", "zCpyM");
         lllIlI[llllll[2]] = lIIllll("Ow4wUySne5g=", "wyWki");
         lllIlI[llllll[3]] = lIlIIII("eonuWAwOWV0=", "HQvET");
         lllIlI[llllll[4]] = lIlIIII("fpnlTrbrawk=", "ScNTW");
         lllIlI[llllll[5]] = lIlIIII("LT/91WB+GqU=", "ofUAn");
         lllIlI[llllll[6]] = lIIlllI("Pg==", "CpCRl");
         lllIlI[llllll[7]] = lIIlllI("WQ==", "uLkgj");
         lllIlI[llllll[8]] = lIlIIII("nbnHKiwCXB0=", "PTWIG");
         lllIlI[llllll[9]] = lIIllll("O3qBbRFIDJA=", "MCJAF");
      }

      public String toString() {
         StringBuilder llllIllIIIIlIll = new StringBuilder();
         Set<Entry<String, Object>> llllIllIIIIIllI = llllIllIIIIllII.map.entrySet();
         llllIllIIIIlIll.append(lllIlI[llllll[0]]);
         "".length();
         char llllIllIIIIIlIl = llllll[0];
         Iterator llllIllIIIIIlII = llllIllIIIIIllI.iterator();

         do {
            if (!lIlllIl(llllIllIIIIIlII.hasNext())) {
               return String.valueOf(llllIllIIIIlIll);
            }

            Entry<String, Object> llllIllIIIIllIl = (Entry)llllIllIIIIIlII.next();
            Object llllIllIIIIlllI = llllIllIIIIllIl.getValue();
            llllIllIIIIlIll.append(llllIllIIIIllII.quote((String)llllIllIIIIllIl.getKey())).append(lllIlI[llllll[1]]);
            "".length();
            String var10001;
            if (lIlllIl(llllIllIIIIlllI instanceof String)) {
               llllIllIIIIlIll.append(llllIllIIIIllII.quote(String.valueOf(llllIllIIIIlllI)));
               "".length();
               "".length();
               if (-" ".length() > " ".length()) {
                  return null;
               }
            } else if (lIlllIl(llllIllIIIIlllI instanceof Integer)) {
               llllIllIIIIlIll.append(Integer.valueOf(String.valueOf(llllIllIIIIlllI)));
               "".length();
               "".length();
               if ("  ".length() > (192 ^ 157 ^ 204 ^ 149)) {
                  return null;
               }
            } else if (lIlllIl(llllIllIIIIlllI instanceof Boolean)) {
               llllIllIIIIlIll.append(llllIllIIIIlllI);
               "".length();
               "".length();
               if ("  ".length() != "  ".length()) {
                  return null;
               }
            } else if (lIlllIl(llllIllIIIIlllI instanceof hitted.JSONObject)) {
               llllIllIIIIlIll.append(llllIllIIIIlllI.toString());
               "".length();
               "".length();
               if (((161 ^ 157 ^ 185 ^ 157) & (95 ^ 79 ^ 151 ^ 159 ^ -" ".length())) > ((168 ^ 192 ^ 83 ^ 109) & (98 ^ 14 ^ 98 ^ 88 ^ -" ".length()))) {
                  return null;
               }
            } else if (lIlllIl(llllIllIIIIlllI.getClass().isArray())) {
               llllIllIIIIlIll.append(lllIlI[llllll[2]]);
               "".length();
               long llllIllIIIIIIIl = Array.getLength(llllIllIIIIlllI);
               int llllIllIIIIIIII = llllll[0];

               while(lIllllI(llllIllIIIIIIII, llllIllIIIIIIIl)) {
                  StringBuilder var10000 = llllIllIIIIlIll.append(Array.get(llllIllIIIIlllI, llllIllIIIIIIII).toString());
                  if (lIlllll(llllIllIIIIIIII, llllIllIIIIIIIl - llllll[1])) {
                     var10001 = lllIlI[llllll[3]];
                     "".length();
                     if (((167 ^ 158 ^ 8 ^ 102) & (201 + 21 - 60 + 57 ^ 62 + 3 - 4 + 79 ^ -" ".length())) != 0) {
                        return null;
                     }
                  } else {
                     var10001 = lllIlI[llllll[4]];
                  }

                  var10000.append(var10001);
                  "".length();
                  ++llllIllIIIIIIII;
                  "".length();
                  if (-" ".length() == ((79 ^ 63 ^ 179 ^ 148) & (179 ^ 160 ^ 249 ^ 189 ^ -" ".length()))) {
                     return null;
                  }
               }

               llllIllIIIIlIll.append(lllIlI[llllll[5]]);
               "".length();
            }

            ++llllIllIIIIIlIl;
            if (llIIIII(llllIllIIIIIlIl, llllIllIIIIIllI.size())) {
               var10001 = lllIlI[llllll[6]];
               "".length();
               if ("   ".length() != "   ".length()) {
                  return null;
               }
            } else {
               var10001 = lllIlI[llllll[7]];
            }

            llllIllIIIIlIll.append(var10001);
            "".length();
            "".length();
         } while(null == null);

         return null;
      }

      private static boolean lIllllI(int var0, int var1) {
         return var0 < var1;
      }

      private static boolean lIlllIl(int var0) {
         return var0 != 0;
      }

      private static boolean lIlllll(int var0, int var1) {
         return var0 != var1;
      }

      void put(String llllIllIIIllllI, Object llllIllIIIlllIl) {
         if (lIlllII(llllIllIIIlllIl)) {
            llllIllIIIlllII.map.put(llllIllIIIllllI, llllIllIIIlllIl);
            "".length();
         }

      }

      private static void lIllIll() {
         llllll = new int[11];
         llllll[0] = (103 ^ 106 ^ 93 ^ 86) & (47 ^ 89 ^ 232 ^ 152 ^ -" ".length());
         llllll[1] = " ".length();
         llllll[2] = "  ".length();
         llllll[3] = "   ".length();
         llllll[4] = 25 ^ 57 ^ 188 ^ 152;
         llllll[5] = 87 ^ 2 ^ 241 ^ 161;
         llllll[6] = 47 ^ 41;
         llllll[7] = 186 ^ 189;
         llllll[8] = 32 ^ 121 ^ 108 ^ 61;
         llllll[9] = 88 ^ 81;
         llllll[10] = "   ".length() ^ 189 ^ 180;
      }

      static {
         lIllIll();
         lIlIIIl();
      }

      private static String lIIlllI(String llllIlIlllIIlIl, String llllIlIlllIlIIl) {
         llllIlIlllIIlIl = new String(Base64.getDecoder().decode(llllIlIlllIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
         boolean llllIlIlllIIIll = new StringBuilder();
         char[] llllIlIlllIIlll = llllIlIlllIlIIl.toCharArray();
         String llllIlIlllIIIIl = llllll[0];
         char llllIlIlllIIIII = llllIlIlllIIlIl.toCharArray();
         boolean llllIlIllIlllll = llllIlIlllIIIII.length;
         int llllIlIllIllllI = llllll[0];

         do {
            if (!lIllllI(llllIlIllIllllI, llllIlIllIlllll)) {
               return String.valueOf(llllIlIlllIIIll);
            }

            char llllIlIlllIlIll = llllIlIlllIIIII[llllIlIllIllllI];
            llllIlIlllIIIll.append((char)(llllIlIlllIlIll ^ llllIlIlllIIlll[llllIlIlllIIIIl % llllIlIlllIIlll.length]));
            "".length();
            ++llllIlIlllIIIIl;
            ++llllIlIllIllllI;
            "".length();
         } while(-" ".length() == -" ".length());

         return null;
      }

      private static String lIlIIII(String llllIlIllIIIllI, String llllIlIllIIIlIl) {
         try {
            byte llllIlIllIIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllIlIllIIIlIl.getBytes(StandardCharsets.UTF_8)), llllll[8]), "DES");
            Cipher llllIlIllIIlIlI = Cipher.getInstance("DES");
            llllIlIllIIlIlI.init(llllll[2], llllIlIllIIIlII);
            return new String(llllIlIllIIlIlI.doFinal(Base64.getDecoder().decode(llllIlIllIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
         } catch (Exception var5) {
            var5.printStackTrace();
            return null;
         }
      }

      private String quote(String llllIlIllllllIl) {
         return String.valueOf((new StringBuilder()).append(lllIlI[llllll[8]]).append(llllIlIllllllIl).append(lllIlI[llllll[9]]));
      }

      // $FF: synthetic method
      JSONObject(Object llllIlIllllIlll) {
         this();
      }

      private static boolean lIlllII(Object var0) {
         return var0 != null;
      }

      private static boolean llIIIII(int var0, int var1) {
         return var0 == var1;
      }

      private JSONObject() {
         llllIllIIlIIlII.map = new HashMap();
      }

      private static String lIIllll(String llllIlIllIlIIll, String llllIlIllIlIlII) {
         try {
            float llllIlIllIlIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllIlIllIlIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
            Cipher llllIlIllIlIlll = Cipher.getInstance("Blowfish");
            llllIlIllIlIlll.init(llllll[2], llllIlIllIlIIIl);
            return new String(llllIlIllIlIlll.doFinal(Base64.getDecoder().decode(llllIlIllIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
         } catch (Exception var4) {
            var4.printStackTrace();
            return null;
         }
      }
   }
}
