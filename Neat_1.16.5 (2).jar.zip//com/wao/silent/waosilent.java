package com.wao.silent;

import com.wao.silent.modules.Hitbox;
import com.wao.silent.modules.key;
import com.wao.silent.ui.draw;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.InterModComms;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.event.lifecycle.InterModEnqueueEvent;
import net.minecraftforge.fml.event.lifecycle.InterModProcessEvent;
import net.minecraftforge.fml.event.server.FMLServerStartingEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("wao")
public class waosilent {
   // $FF: synthetic field
   private static final String[] llllIl;
   // $FF: synthetic field
   private static final int[] lIIIIII;
   // $FF: synthetic field
   private static final Logger LOGGER;

   @SubscribeEvent
   public void onServerStarting(FMLServerStartingEvent llllIlIlIlIIIlI) {
      LOGGER.info(llllIl[lIIIIII[6]]);
   }

   static {
      llIIIlI();
      lIllIlI();
      LOGGER = LogManager.getLogger();
   }

   private static void lIllIlI() {
      llllIl = new String[lIIIIII[9]];
      llllIl[lIIIIII[0]] = lIlIIlI("oxRKb2zZBKuAO7W/PeY7hCtJqQMRrH4a", "LTRmJ");
      llllIl[lIIIIII[1]] = lIlIIlI("hO2C78x6cfDsXCgUlOx6Y636rjsc6Ocw", "GlilK");
      llllIl[lIIIIII[2]] = lIlIIlI("5cv/GLyd2MtlEHg9pLqxEuIsG9VorLOI", "EFPxa");
      llllIl[lIIIIII[3]] = lIllIII("CBkpDwYBBCUNEg==", "maHbv");
      llllIl[lIIIIII[4]] = lIllIII("BykECgUYIxoKDg==", "oLhfj");
      llllIl[lIIIIII[5]] = lIlIIlI("9/pmkcmi7ASe/sRVYvROkg==", "SEako");
      llllIl[lIIIIII[6]] = lIllIII("KQA0PD1BIwofH0E2HQIEBDdYAwYANwwZHAY=", "aExpr");
      llllIl[lIIIIII[7]] = lIlIIlI("oLEViqcMjNR7skcwtK2WhHbeobItxu6LhItGYjqJA4o=", "ZYgmm");
      llllIl[lIIIIII[8]] = lIllIIl("YPZe+wScz3ESOjUaqiucqA==", "RYYCk");
   }

   private void doClientStuff(FMLClientSetupEvent llllIlIlIlIlIll) {
      LOGGER.info(llllIl[lIIIIII[2]], ((Minecraft)llllIlIlIlIlIll.getMinecraftSupplier().get()).field_71474_y);
   }

   private void setup(FMLCommonSetupEvent llllIlIlIlIlllI) {
      LOGGER.info(llllIl[lIIIIII[0]]);
      LOGGER.info(llllIl[lIIIIII[1]], Blocks.field_150346_d.getRegistryName());
   }

   private static String lIllIII(String llllIlIIllllIlI, String llllIlIIllllIIl) {
      llllIlIIllllIlI = new String(Base64.getDecoder().decode(llllIlIIllllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      String llllIlIIlllIIll = new StringBuilder();
      char[] llllIlIIlllIlll = llllIlIIllllIIl.toCharArray();
      float llllIlIIlllIIIl = lIIIIII[0];
      boolean llllIlIIlllIIII = llllIlIIllllIlI.toCharArray();
      long llllIlIIllIllll = llllIlIIlllIIII.length;
      int llllIlIIllIlllI = lIIIIII[0];

      do {
         if (!llIIIll(llllIlIIllIlllI, llllIlIIllIllll)) {
            return String.valueOf(llllIlIIlllIIll);
         }

         char llllIlIIllllIll = llllIlIIlllIIII[llllIlIIllIlllI];
         llllIlIIlllIIll.append((char)(llllIlIIllllIll ^ llllIlIIlllIlll[llllIlIIlllIIIl % llllIlIIlllIlll.length]));
         "".length();
         ++llllIlIIlllIIIl;
         ++llllIlIIllIlllI;
         "".length();
      } while(-" ".length() >= -" ".length());

      return null;
   }

   private static void llIIIlI() {
      lIIIIII = new int[10];
      lIIIIII[0] = (73 ^ 104) & ~(103 ^ 70);
      lIIIIII[1] = " ".length();
      lIIIIII[2] = "  ".length();
      lIIIIII[3] = "   ".length();
      lIIIIII[4] = 167 ^ 163;
      lIIIIII[5] = 54 ^ 51;
      lIIIIII[6] = 1 ^ 9 ^ 72 ^ 70;
      lIIIIII[7] = 127 ^ 53 ^ 213 ^ 152;
      lIIIIII[8] = 251 ^ 136 ^ 201 ^ 178;
      lIIIIII[9] = 33 ^ 40;
   }

   private void enqueueIMC(InterModEnqueueEvent llllIlIlIlIlIII) {
      InterModComms.sendTo(llllIl[lIIIIII[3]], llllIl[lIIIIII[4]], () -> {
         LOGGER.info(llllIl[lIIIIII[7]]);
         return llllIl[lIIIIII[8]];
      });
      "".length();
   }

   private static String lIlIIlI(String llllIlIlIIIlIII, String llllIlIlIIIlIIl) {
      try {
         Exception llllIlIlIIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllIlIlIIIlIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
         Cipher llllIlIlIIIllII = Cipher.getInstance("Blowfish");
         llllIlIlIIIllII.init(lIIIIII[2], llllIlIlIIIIllI);
         return new String(llllIlIlIIIllII.doFinal(Base64.getDecoder().decode(llllIlIlIIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var5) {
         var5.printStackTrace();
         return null;
      }
   }

   private void processIMC(InterModProcessEvent llllIlIlIlIIlIl) {
      LOGGER.info(llllIl[lIIIIII[5]], llllIlIlIlIIlIl.getIMCStream().map((llllIlIlIlIIIII) -> {
         return llllIlIlIlIIIII.getMessageSupplier().get();
      }).collect(Collectors.toList()));
   }

   private static boolean llIIIll(int var0, int var1) {
      return var0 < var1;
   }

   public waosilent() {
      FMLJavaModLoadingContext.get().getModEventBus().addListener(llllIlIlIllIIIl::setup);
      FMLJavaModLoadingContext.get().getModEventBus().addListener(llllIlIlIllIIIl::enqueueIMC);
      FMLJavaModLoadingContext.get().getModEventBus().addListener(llllIlIlIllIIIl::processIMC);
      FMLJavaModLoadingContext.get().getModEventBus().addListener(llllIlIlIllIIIl::doClientStuff);
      MinecraftForge.EVENT_BUS.register(llllIlIlIllIIIl);
      MinecraftForge.EVENT_BUS.register(new draw());
      MinecraftForge.EVENT_BUS.register(new Hitbox());
      MinecraftForge.EVENT_BUS.register(new key());
      MinecraftForge.EVENT_BUS.register(new waolol());
   }

   private static String lIllIIl(String llllIlIlIIlIlll, String llllIlIlIIlIllI) {
      try {
         SecretKeySpec llllIlIlIIllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllIlIlIIlIllI.getBytes(StandardCharsets.UTF_8)), lIIIIII[8]), "DES");
         Exception llllIlIlIIlIIlI = Cipher.getInstance("DES");
         llllIlIlIIlIIlI.init(lIIIIII[2], llllIlIlIIllIlI);
         return new String(llllIlIlIIlIIlI.doFinal(Base64.getDecoder().decode(llllIlIlIIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   @EventBusSubscriber(
      bus = Bus.MOD
   )
   public static class RegistryEvents {
      // $FF: synthetic field
      private static final int[] lIIllIl;
      // $FF: synthetic field
      private static final String[] lIIlIlI;

      @SubscribeEvent
      public static void onBlocksRegistry(Register<Block> llllIIllIIlIlIl) {
         waosilent.LOGGER.info(lIIlIlI[lIIllIl[0]]);
      }

      private static String llIlIIl(String llllIIllIIIlIll, String llllIIllIIIllII) {
         try {
            SecretKeySpec llllIIllIIlIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllIIllIIIllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
            Cipher llllIIllIIIllll = Cipher.getInstance("Blowfish");
            llllIIllIIIllll.init(lIIllIl[2], llllIIllIIlIIII);
            return new String(llllIIllIIIllll.doFinal(Base64.getDecoder().decode(llllIIllIIIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
         } catch (Exception var4) {
            var4.printStackTrace();
            return null;
         }
      }

      private static void llIllII() {
         lIIlIlI = new String[lIIllIl[1]];
         lIIlIlI[lIIllIl[0]] = llIlIIl("oap/6OtAYIPtUWA1BhAuHhWPwg3a4KdC+kFBCQkgahY=", "IKxBV");
      }

      static {
         lllIlIl();
         llIllII();
      }

      private static void lllIlIl() {
         lIIllIl = new int[3];
         lIIllIl[0] = (123 ^ 75) & ~(89 ^ 105);
         lIIllIl[1] = " ".length();
         lIIllIl[2] = "  ".length();
      }
   }
}
