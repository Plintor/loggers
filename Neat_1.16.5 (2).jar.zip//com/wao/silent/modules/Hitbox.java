package com.wao.silent.modules;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class Hitbox {
   // $FF: synthetic field
   public static double size = 0.4D;

   public static void setSize(double lllllIIIIIIlIII) {
      size = lllllIIIIIIlIII;
   }

   @SubscribeEvent
   public void onUpdate(RenderPlayerEvent lllllIIIIIIllII) {
      Entity lllllIIIIIIllIl = lllllIIIIIIllII.getEntity();
      Minecraft.func_71410_x().field_71474_y.field_74333_Y = 1000.0D;
      lllllIIIIIIllIl.func_174826_a(new AxisAlignedBB(lllllIIIIIIllIl.func_226277_ct_() - size, lllllIIIIIIllIl.func_174813_aQ().field_72338_b, lllllIIIIIIllIl.func_226281_cx_() - size, lllllIIIIIIllIl.func_226277_ct_() + size, lllllIIIIIIllIl.func_174813_aQ().field_72337_e, lllllIIIIIIllIl.func_226281_cx_() + size));
   }

   public static double getSize() {
      return size;
   }
}
