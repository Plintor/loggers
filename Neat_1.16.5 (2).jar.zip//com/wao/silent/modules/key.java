package com.wao.silent.modules;

import com.wao.silent.ui.draw;
import net.minecraftforge.client.event.InputEvent.KeyInputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class key {
   // $FF: synthetic field
   private static final int[] llIIII;

   static {
      lIIlIII();
   }

   private static void lIIlIII() {
      llIIII = new int[6];
      llIIII[0] = 59 ^ 90;
      llIIII[1] = (74 ^ 25 ^ 73 + 121 - 136 + 69) & (84 ^ 101 ^ 218 ^ 199 ^ -" ".length());
      llIIII[2] = 47 + 148 - 174 + 187 ^ 120 + 167 - 223 + 114;
      llIIII[3] = " ".length();
      llIIII[4] = 9 ^ 5 ^ 71 ^ 0;
      llIIII[5] = 39 ^ 109;
   }

   private static boolean lIIlIIl(int var0, int var1) {
      return var0 == var1;
   }

   @SubscribeEvent
   public void key(KeyInputEvent lllllIIIIIllIlI) {
      byte lllllIIIIIllIIl = lllllIIIIIllIlI.getKey();
      if (lIIlIIl(lllllIIIIIllIIl, llIIII[0])) {
         draw.drowFps = llIIII[1];
      }

      if (lIIlIIl(lllllIIIIIllIIl, llIIII[2])) {
         draw.drowFps = llIIII[3];
      }

      if (lIIlIIl(lllllIIIIIllIIl, llIIII[4])) {
         Hitbox.setSize(Hitbox.size + 0.05D);
      }

      if (lIIlIIl(lllllIIIIIllIIl, llIIII[5])) {
         Hitbox.setSize(Hitbox.size - 0.05D);
      }

   }
}
